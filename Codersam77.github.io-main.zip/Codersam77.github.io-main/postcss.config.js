/*
 * Copyright 2024 Samuel Sanchez. 
 */


module.exports = {
  plugins: {
    autoprefixer: {},
    tailwindcss: {},
  },
}

/*
 * Copyright 2024 Samuel Sanchez. 
 */
